export default {
  apiKey: "AIzaSyBIAPdsdx2TgJaj_X28W0NGnLztuz5If6U",
  authDomain: "tcs-a63b1.firebaseapp.com",
  databaseURL: "https://tcs-a63b1.firebaseio.com",
  projectId: "tcs-a63b1",
  storageBucket: "tcs-a63b1.appspot.com",
  messagingSenderId: "1080693456758",
  appId: "1:1080693456758:web:6dbd711345732011a1c457"
};
