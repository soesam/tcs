<template>
  <div styles="margin-left:0">
    <v-app-bar
    width="100%"
    app
    clipped>
    </v-app-bar>
    <br/>
    <TeacherNavigation/>
    <v-main>
      <v-container
      fluid
      >
        <Classes/>
      </v-container>
    </v-main>
  </div>
</template>

<script>
import Classes from "../components/Classes.vue";
import TeacherNavigation from "../components/TeacherNavigation.vue";
  export default {
    data() {
      return {
        items: ["Classes", "Homework", "Reports"]
      }
    },

    components: {
      Classes,
      TeacherNavigation
    }
  }
</script>
