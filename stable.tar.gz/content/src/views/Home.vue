<template>
  <div class="home">
    <h1 class="display-4">Welcome</h1>
    <h2 class="display-3">Welcome</h2>
    <h3 class="display-2">Welcome</h3>
    <h4 class="display-1">Welcome</h4>
  </div>
</template>
