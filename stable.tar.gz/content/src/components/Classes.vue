import Vuetify from 'vuetify'
import Vue from "vue";

<template>
  <div>
    <v-container>
      <v-card
        class="mx-auto"
        max-width="250"
        max-height="300"
        min-width="200"
        outlined="true"
        elevation="6"
        v-for="(title, tIndex) in titles" :key="tIndex">
        <v-card-title> {{ title }} </v-card-title>
        <br/>
        <v-card-text>{{ teachers[tIndex] }}</v-card-text>
        <v-card-subtitle>Students:</v-card-subtitle>
        <div class="list">
          <v-card-text v-for="(c, cIndex) in classes[tIndex]" :key="cIndex">{{c}}</v-card-text>
        </div>
      </v-card>
    </v-container>
  </div>
</template>

<script>
  var Airtable = require("airtable");
  const sleep = function(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  };
  export default {
    name: "Classes",
    data() {
      return {
        apiUrl: "https://api.airtable/com/v0/appvLWxrF80mDK8Xq/",
        apiKey: "keyLVnvjV4bFHXOaD",
        records: [],
        classes: [],
        titles: [],
        teachers: []
      };
    },

    mounted: async function() {
      var v;
      v = this.teacherData()
      this.showData(v)
    },

    methods: {

    showData: async function(teacher) {
      this.records = this.getData()
      await sleep(500);
      var i;
      var l;
      var t;
      var cls = [];
      let students = this.records[0];
      let clas = this.records[1];
      for (i=0; i < clas.length; i++) {
        for (t=0; t < teacher.length; t++) {

          if (clas[i].fields.tid[0] === teacher[t].id) {
            cls.push(clas[i]);
            this.teachers.push(teacher[t].fields.Name + " " + teacher[t].fields.Surname)
          }
        }
      }
      for (i=0; i < cls.length; i++) {
        l = this.checkData(students, cls[i]);
        this.titles.push(cls[i].fields.Name)
        this.classes.push(l);
      }
    },
    teacherData: function() {
      var list = [];
      var base = new Airtable({ apiKey: "keyLVnvjV4bFHXOaD" }).base(
        "appvLWxrF80mDK8Xq"
      );
      base("Staff")
        .select({
          view: "Grid view"
        })
        .eachPage(
          function page(records, fetchNextPage) {
            records.forEach(function(record) {
              list.push(record);
            });
            fetchNextPage();
          },
          function done(err) {
            if (err) {
              console.error(err);
              return;
            }
          }
        );
        return list;
    },

    //Function used to add points to airtable
    pointUp: async function(key, no) {
      var base = new Airtable({ apiKey: "keyLVnvjV4bFHXOaD" }).base(
        "appvLWxrF80mDK8Xq"
      );
      var points = 0;
      function fetch(err, record) {
        if (err) {
          console.error(err);
          return;
        }
        points = record.get("Points");
        var newPoints = points + no;
        base("Student").update([
          {
            id: key,
            fields: {
              Points: newPoints
            }
          }
        ]);
      }
      await sleep(500);
      base("Student").find(key, fetch);
      this.showData();
    },

    //Function used to delete a student's record
    deleteThis: function(key) {
      var base = new Airtable({ apiKey: "keyLVnvjV4bFHXOaD" }).base(
        "appvLWxrF80mDK8Xq"
      );
      base("Student").destroy([key], function(err) {
        if (err) {
          console.error(err);
          return;
        }
        this.showData();
      });
    },

    //Gives opposite of value put in (Boolean only)
    change: function(value) {
      value = !value;
      return value;
    },

    //Gets data from airtable
    getData: function() {
      var list = [];
      var list1 = [];
      var allList = [];
      var base = new Airtable({ apiKey: "keyLVnvjV4bFHXOaD" }).base(
        "appvLWxrF80mDK8Xq"
      );
      base("Student")
        .select({
          view: "Grid view"
        })
        .eachPage(
          function page(records, fetchNextPage) {
            records.forEach(function(record) {
              list.push(record);
            });
            fetchNextPage();
          },
          function done(err) {
            if (err) {
              console.error(err);
              return;
            }
          }
        );
        base("Class")
          .select({
            view: "Grid view"
          })
          .eachPage(
            function page(records, fetchNextPage) {
              records.forEach(function(record) {
                list1.push(record);
              });
              fetchNextPage();
            },
            function done(err) {
              if (err) {
                console.error(err);
                return;
              }
            }
          );
          allList.push(list);
          allList.push(list1);
          return allList;
    },

    checkData: function(data, classs) {
      var studentList = [];
      var studentList1 = [];
      var i;
      var t;
      var l;
      studentList = classs.fields.Members;
      for (i = 0; i < studentList.length; i++) {
        for (t = 0; t < data.length; t++) {
          if (data[t].fields.Member[0] == studentList[i]) {
            l = data[t].fields.Name + " " + data[t].fields.Surname;
            studentList1.push(l);
              }
            }
          }
          return studentList1;
        }
      }
    };
</script>

<style>
  div {
    margin-left: 0;
    display: flex;
    overflow-y: hidden;
    padding: 0;
  }
  .list {
    overflow-y: scroll;
    max-height: 128px;
    display: block;
  }
  .v-card__text { padding-top: 2px; }
  .v-card__subtitle { padding-top: 4px; }
  .v-container {
    padding-left: 16px;
    padding-right: 16px;
            }
</style>
