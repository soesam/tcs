<template>
  <!-- <v-app-bar dense>
    <v-app-bar-title>Title</v-app-bar-title>
    <v-spacer></v-spacer>

    <v-btn icon>
      <v-icon>search</v-icon>
    </v-btn>

    <v-btn icon>
      <v-icon>favorite</v-icon>
    </v-btn>

    <v-btn icon>
      <v-icon>more_vert</v-icon>
    </v-btn>
  </v-app-bar> -->

  <div class="header"></div>
</template>
