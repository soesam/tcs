## tcs.io

A simple web app for Thames Christian School's data needs.
