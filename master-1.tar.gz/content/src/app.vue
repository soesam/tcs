<template>
  <v-app class="gray lighten-4">
    <router-view></router-view>
    <v-footer app></v-footer>
  </v-app>
</template>
